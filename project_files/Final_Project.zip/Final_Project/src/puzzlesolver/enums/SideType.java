package puzzlesolver.enums;

public enum SideType {
  IN, OUT, FLAT
}
