package puzzlesolver.test.ui;

import org.junit.Test;

import puzzlesolver.Point;

public class PuzzleControllerTest {

  Point p0_0 = new Point(0, 0);

  @Test
  public void testGetRequiredWidth() throws Exception {

  }

  @Test
  public void testGetRequiredHeight() throws Exception {

  }

  @Test
  public void testGlobalPointFromLocalPoint() throws Exception {
  }
}
