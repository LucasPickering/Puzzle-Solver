# Puzzle-Solver
A jigsaw puzzle-solving algorithm.

Style: [Google Style Guide](https://google.github.io/styleguide/javaguide.html)
Tabs: 2 spaces